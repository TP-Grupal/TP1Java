package juego;
	
	import entorno.Entorno;
	import entorno.Herramientas;
	import java.awt.Image;
	
	public class Elizabeth {
		private int x;
		private int y;
		private double angulo;
		private double diametro;
		private Image rayoEli;
		private int ultDirec;
		
		
		
		private int alto;
		private int ancho;
		
		//salto princesa
		private double velocidadY;
		private int gravedad;
		
		//imagen movimiento
		private Image movDer;
		private Image movIzq;
		private Image porDefecto;
		public Elizabeth(Image movDer,Image movIzq,int x, int y, double angulo, double diametro, int velocidad,int ultDirec) {
			this.porDefecto = Herramientas.cargarImagen("Imagenes\\elizabeth.png");
			this.x = x;
			this.y = y;
			this.angulo = angulo;
			this.diametro = diametro;
			this.ultDirec = ultDirec;
			
			this.alto = alto;
			this.ancho = ancho;
			
			//salto princesa
			this.velocidadY = 0; // velocidad salto
			this.gravedad = 6;
			
		}
		public void dibujarImg(Entorno entorno) {
		    if (this != null) {
		        this.y = (int) (this.y + velocidadY);
		        entorno.dibujarImagen(this.porDefecto, this.x, this.y, this.angulo, this.diametro);
		    }
		}

		
		public void moverDerecha()
		{
			this.x = this.x + 3;
			this.movDer = Herramientas.cargarImagen("Imagenes\\mov-der.gif");
			this.porDefecto = this.movDer;
		}
		
		
		public void moverIzquierda()
		{
			this.x = this.x - 3;
			this.movIzq = Herramientas.cargarImagen("Imagenes\\mov-izq.gif");
			this.porDefecto = this.movIzq;
		}
		public Rayo disparar() {
			this.rayoEli = Herramientas.cargarImagen("Imagenes\\rayo.png");
			return new Rayo(rayoEli, this.x, this.y, 0, 0.1, 10);
		}
		
		public int getX() {
			return x;
		}
	
	
		public int getY() {
			return y;
		}
	
		/**
	     * @return double return the angulo
	     */
	    public double getAngulo() {
	        return angulo;
	    }
	
	    /**
	     * @param angulo the angulo to set
	     */
	    public void setAngulo(double angulo) {
	        this.angulo = angulo;
	    }
	
	    /**
	     * @return double return the diametro
	     */
	    public double getDiametro() {
	        return diametro;
	    }
	
	    /**
	     * @param diametro the diametro to set
	     */
	    public void setDiametro(double diametro) {
	        this.diametro = diametro;
	    }
	    public int getUltDirec() {
		return ultDirec;
	    }
	    public void setUltDirec(int ultDirec) {
		this.ultDirec = ultDirec;
	    }
	    
	    public int saltar2() { 
	    	return this.y = this.y - 5;
	    }
	    
		public int getAlto() {
			return alto;
		}
		public int getAncho() {
			return ancho;
		}
	    
	    public void gravedadPrincesa() {
	    	this.y = this.y + gravedad;
	    }
}
	
	
