package juego;
import java.awt.Color;
import java.awt.Image;

import javax.swing.ImageIcon;

import entorno.Entorno;
import entorno.Herramientas;

public class Menu {
    private boolean enMenu;
    private Image fondo; 
    public Menu(Image fondo) {
        this.enMenu = true;
        this.fondo = Herramientas.cargarImagen("Imagenes\\fondoMenu.gif");
        //fondo = new ImageIcon("C:\\Users\\Usuario\\Desktop\\copia del tp grupo por si las dudas\\src\\imagenes\\fondoMenu.gif").getImage();
    }

    public void dibujarTitulo(Entorno entorno) {
        // Dibuja el título del juego
        entorno.cambiarFont("Arial", 24, Color.WHITE);
        entorno.escribirTexto("Super Elizabeth Sis", 380, 200);
    }

    public void dibujarElementosMenu(Entorno entorno) {
        // Dibuja los elementos del menú 
        entorno.cambiarFont("Arial", 18, Color.WHITE);
        // Elementos del menú (por ejemplo, "Empezar", "Opciones", etc.)        
        entorno.escribirTexto("Presione Enter Para Empezar", 370, 300);
        //entorno.escribirTexto("Salir", 400, 400);
    }
    
    public void dibujarFondo(Entorno entorno) {
    entorno.dibujarImagen(this.fondo, entorno.ancho() / 2, entorno.alto() / 2, 0);
    }
    
    public boolean estaEnMenu() {
        return enMenu;
    }

    public void cambiarEstado() {
        enMenu = !enMenu;
    }
}